@extends('layouts/master', ['title' => ''])

@section('content')

@endsection